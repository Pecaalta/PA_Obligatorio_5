#include "IKey.h"

IKey::~IKey(){
    
}