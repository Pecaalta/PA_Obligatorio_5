
#include "ICollection.h"

ICollection::~ICollection()
{
    
}